﻿namespace TimeZero.Auction.Bot.Controls.TreeViewSearchBox
{
    public enum SearchResultView
    {
        Tree,
        List
    }
}
