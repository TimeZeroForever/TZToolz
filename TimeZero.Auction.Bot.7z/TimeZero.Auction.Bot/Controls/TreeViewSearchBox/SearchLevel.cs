﻿namespace TimeZero.Auction.Bot.Controls.TreeViewSearchBox
{
    public enum SearchLevel
    {
        Root,
        FirstChild
    }
}
