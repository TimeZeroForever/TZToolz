﻿namespace TimeZero.Auction.Bot.Network.Constants
{
    public static class PacketType
    {
        public const string GAME_BOT_DATA   = "BOT"   ;
        public const string GAME_ERROR_DATA = "ERROR" ;
    }
}
