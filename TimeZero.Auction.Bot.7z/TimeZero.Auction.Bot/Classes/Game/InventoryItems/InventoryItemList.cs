﻿using System.Collections.Generic;

namespace TimeZero.Auction.Bot.Classes.Game.InventoryItems
{
    public sealed class InventoryItemList : List<InventoryItem> { }
}
