﻿namespace TimeZero.Auction.Bot.Classes.Game.GameItems
{
    public static class GameItemModificationType
    {
        public const string M1          = "M1"      ;
        public const string M2          = "M2"      ;
        public const string M3          = "M3"      ;
        public const string SE          = "SE"      ;
        public const string PVP         = "PvP"     ;
        public const string PVE         = "PvE"     ;
        public const string APSE        = "APSE"    ;
        public const string PANIC_MF    = "Panic MF";
        public const string BIO_MF      = "Bio MF"  ;
        public const string HAL_MF      = "HalMF"   ;
    }
}
