﻿namespace TimeZero.Auction.Bot.Classes.MemoryEditor
{
    public enum SysType : sbyte
    {
        Unknown,
        Byte,
        SByte,
        Char,
        Short,
        UShort,
        Int,
        UInt,
        Long,
        ULong,
        Float,
        Double,
        String,
        ByteArray
    }
}
