﻿using System;
using System.IO;
using System.Windows.Forms;
using Voice2Dox.LocalSettings;

namespace TimeZero.Auction.Bot.Forms
{
    public partial class frmSettings : Form
    {

#region Private fields

        private string _gameFolder;

#endregion

#region Properties

        public bool IsGameFolderChanged { get; private set; }

#endregion

#region Class methods

        public frmSettings()
        {
            InitializeComponent();
            tbSettings.Top -= 22;
            tbSettings.Height += 22;
            lvSettings.Items[0].Selected = true;
        }

        private void PopulateSettings()
        {
            //General settings
            tbGameServer.Text = Settings.Instance["Server"];
            tbGamePort.Text = Settings.Instance["Port"];
            tbGameFolder.Text = Settings.Instance["GameFolder"];
            tbClientVer1.Text = Settings.Instance["ClientVersion"];
            tbClientVer2.Text = Settings.Instance["ClientVersion2"];
            tbLogin.Text = Settings.Instance["Login"];
            tbPassword.Text = Settings.Instance["Password"];

            //Main windows settings
            cbOutLogInfo.Checked = Settings.Instance.GetBool("OutLogs");
            cbOutDetailedLogInfo.Checked = Settings.Instance.GetBool("OutDetailedLogs");

            //Init local variables
            _gameFolder = tbGameFolder.Text;
        }

        public bool Execute()
        {
            PopulateSettings();
            return ShowDialog() == DialogResult.OK;
        }

        private int GetTabIndex(int itemIndex)
        {
            int tabIdx = itemIndex;
            for (int i = tabIdx - 1; i >= 0; i--)
            {
                ListViewItem item = lvSettings.Items[i];
                if (item.Text == "-")
                {
                    tabIdx--;
                }
            }
            return tabIdx;
        }

        private void lvSettings_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvSettings.SelectedIndices.Count > 0 && lvSettings.SelectedIndices[0] != -1)
            {
                tbSettings.SelectedIndex = GetTabIndex(lvSettings.SelectedIndices[0]);
                tbSettings.SelectedTab.Focus();
            }
        }

        private void btnBrowseGameFolder_Click(object sender, EventArgs e)
        {
            if (fbdGameFolder.ShowDialog() == DialogResult.OK)
            {
                tbGameFolder.Text = fbdGameFolder.SelectedPath;
            }
        }

        private bool SaveAppSettings()
        {
            Cursor = Cursors.WaitCursor;
            try
            {
                //Check game server
                string gameServer = tbGameServer.Text.Trim();
                if (string.IsNullOrEmpty(gameServer))
                {
                    tbGameServer.Focus();
                    throw new Exception("Game server is not defined");
                }

                //Parse game port value
                int gamePort;
                if (!int.TryParse(tbGamePort.Text.Trim(), out gamePort) ||
                    gamePort <= 1024 || gamePort > 65535)
                {
                    tbGamePort.Focus();
                    throw new Exception("Invalid game port");
                }

                //Check client version 1
                string clientVer1 = tbClientVer1.Text.Trim();
                if (string.IsNullOrEmpty(clientVer1))
                {
                    tbClientVer1.Focus();
                    throw new Exception("Client version 1 is not defined");
                }

                //Check client version 2
                string clientVer2 = tbClientVer2.Text.Trim();
                if (string.IsNullOrEmpty(clientVer2))
                {
                    tbClientVer2.Focus();
                    throw new Exception("Client version 2 is not defined");
                }

                //Check game folder
                string gameFolder = tbGameFolder.Text.Trim();
                string mainSwfFile = Path.Combine(gameFolder, "tz.swf");
                if (string.IsNullOrEmpty(gameFolder) || !File.Exists(mainSwfFile))
                {
                    tbGameFolder.Focus();
                    throw new Exception("Game folder is incorrect");
                }
                if (gameFolder[gameFolder.Length - 1] == '\\')
                {
                    gameFolder = gameFolder.Remove(gameFolder.Length - 1, 1);
                }

                //Check login
                string login = tbLogin.Text.Trim();
                if (string.IsNullOrEmpty(login))
                {
                    tbLogin.Focus();
                    throw new Exception("Game login is empty");
                }

                //Check password
                string password = tbPassword.Text.Trim();
                if (string.IsNullOrEmpty(password))
                {
                    tbPassword.Focus();
                    throw new Exception("Password is empty");
                }

                //Store settings

                //1. General settings
                Settings.Instance["Server"] = gameServer;
                Settings.Instance["Port"] = gamePort.ToString();
                Settings.Instance["GameFolder"] = gameFolder;
                Settings.Instance["ClientVersion"] = clientVer1;
                Settings.Instance["ClientVersion2"] = clientVer2;
                Settings.Instance["Login"] = login;
                Settings.Instance["Password"] = password;

                //2. Main windows settings
                Settings.Instance["OutLogs"] = cbOutLogInfo.Checked.ToString();
                Settings.Instance["OutDetailedLogs"] = cbOutDetailedLogInfo.Checked.ToString();

                //3. Set properties
                IsGameFolderChanged = !gameFolder.Equals(_gameFolder ?? "", StringComparison.InvariantCultureIgnoreCase);

                //Save settings
                Settings.Instance.Save();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Saving error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return false;
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void SaveSettings()
        {
            if (SaveAppSettings())
            {
                DialogResult = DialogResult.OK;
            }
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            SaveSettings();
        }

        private void frmSettings_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Escape:
                    {
                        Close();
                        break;
                    }
                case Keys.Enter:
                    {
                        SaveSettings();
                        break;
                    }
            }
        }

#endregion

    }
}
